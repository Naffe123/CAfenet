package com.example.lenovo.cafenet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class NewsHighlights extends AppCompatActivity {

    ListView lst;
    String[] months={"Coffee shop chain Second Cup establishes special committee to review options",
            "The Canadian coffee shop chain Tim Hortons has announced it will open more than 1,500 branches in China over the next decade.",
            "Tim Hortons now boasts 4,700 locations worldwide, mostly in Canada and the United States.",
            "Tim Horton – has become a staple along Canada’s roadways since opening its first counter in 1964 in Hamilton, Ontario.",
            "Deaf customers at a new Starbucks shop in the US will be able to use American Sign Language to order drinks.",
            "The Second Cup's CEO is leaving the company abruptly, three years after the former Holt Renfrew executive was brought on to lead a rejuvenation of the Canadian coffee chain.",
            "The parent company of Tim Hortons saw sales growth at Canadian locations of the coffee-and-doughnut chain as executives say their work to mend fraught franchisee relations is paying off, though more work remains.",
            "Starbucks will close all its Canadian company-operated stores and offices for an afternoon next month to provide training about creating a \"culture of warmth and belonging."


    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_highlights);
        lst= (ListView) findViewById(R.id.list);
        ArrayAdapter<String> arrayadapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,months);
        lst.setAdapter(arrayadapter);
    }
}