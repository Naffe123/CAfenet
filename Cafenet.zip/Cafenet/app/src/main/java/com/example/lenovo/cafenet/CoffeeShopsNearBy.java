package com.example.lenovo.cafenet;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class CoffeeShopsNearBy extends AppCompatActivity {

    ListView lstview;
    String[] months={"Starbucks - CF Fairview Mall",
            "Timothy's Coffee - North York,ON",
            "Golden Gecko Coffee - 282 Jane St,Toronto",
            "Coffee TIme - North York,ON","Aroma Expresso Bar - CF Fairview Mall ",
            "Tim Hortons - CF Fairview Mall",
            "Second Cup - York Mills Garden ",
            "McDonald's - CF Fairview Mall, Manic Coffee - Toronto,ON",
            "Toffee Cafe - North York,ON", "Tarts Treats and Coffee - 1700 Sheppard Ave E ",
            "Starbucks - 2555 victoria park ave ", "Donut Counter - North York,ON","" +
            "York Land Cafe - North York,ON", "Tim Horton's - North York,ON"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coffee_shops_near_by);
        lstview= (ListView) findViewById(R.id.lstview);
        ArrayAdapter<String> arrayadapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,months);
        lstview.setAdapter(arrayadapter);
    }
}
