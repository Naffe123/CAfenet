package com.example.lenovo.cafenet;

import android.content.Intent;
import android.database.Cursor;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class ProfileActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    EditText editfirstname, editlastname,editid;
    Button Adddata,Modifydata,viewAlldata;
    ImageButton btncamera;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        btncamera = (ImageButton)findViewById(R.id.btn_camera);
        btncamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent p = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivity(p);
            }
        });

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        databaseHelper = new DatabaseHelper(this);
        editid = (EditText)findViewById(R.id.idname);
        editfirstname = (EditText)findViewById(R.id.editText);
        editlastname = (EditText)findViewById(R.id.editText1);
        Adddata = (Button)findViewById(R.id.btnsave);
        Modifydata = (Button)findViewById(R.id.btnupdate);
        viewAlldata = (Button)findViewById(R.id.btnalldata);


        addData();
        updateData();
        viewAllData();
    }


    public void addData() {
        Adddata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = databaseHelper.insertData(editfirstname.getText().toString(),
                        editlastname.getText().toString());
                if (isInserted == true) {
                    Toast.makeText(ProfileActivity.this, "Data Added.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ProfileActivity.this, "Data Not Added.", Toast.LENGTH_SHORT).show();
                }
                eraseEditTextAfterInput();
            }
        });


    }


    public void updateData() {
        Modifydata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isUpdated = databaseHelper.updateData(editid.getText().toString(),
                        editfirstname.getText().toString(), editlastname.getText().toString());
                if (isUpdated == true) {
                    Toast.makeText(ProfileActivity.this, "Data Updated.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ProfileActivity.this, "Data Not Updated.", Toast.LENGTH_SHORT).show();
                }
                eraseEditTextAfterInput();

            }
        });
    }
    public void viewAllData() {
        viewAlldata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor resultCursor = databaseHelper.getallData();
                if (resultCursor.getCount() == 0) {
                    // Show message (see method below this one).
                    showMessage("Error.", "No Data Found.");
                    return;
                }
                StringBuffer stringBuffer = new StringBuffer();
                while (resultCursor.moveToNext()) {
                    stringBuffer.append("ID: " + resultCursor.getString(0) + "\n");
                    stringBuffer.append("First Name: " + resultCursor.getString(1) + "\n");
                    stringBuffer.append("Last Name: " + resultCursor.getString(2) + "\n");

                }
                // Show all data.
                showMessage("Data", stringBuffer.toString());
            }
        });
    }

    public void showMessage(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    public void eraseEditTextAfterInput() {
        editfirstname.setText("");
        editlastname.setText("");
        editid.setText("");
    }



}
